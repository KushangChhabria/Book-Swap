import React from "react";
import "./Home.css";

const Home = () => {
  return (
    <div className="home">
      <section className="about-us">
        <h2>About Us</h2>
        <p>
          Welcome to Bookverse - Your one-stop solution for buying, renting, and
          selling books.
        </p>
      </section>
      <section className="recommendations">
        <h2>Book Recommendations</h2>
        <div className="book-list">{/* Map through books here */}</div>
      </section>
      <footer>
        <p>Newsletter | Help | Contact Us</p>
      </footer>
    </div>
  );
};

export default Home;
