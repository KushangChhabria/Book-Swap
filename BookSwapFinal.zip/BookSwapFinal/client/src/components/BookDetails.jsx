// src/components/BookDetails.jsx

import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

const BookDetails = () => {
  const { bookId } = useParams();
  const [book, setBook] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/api/books/${bookId}`)
      .then((res) => res.json())
      .then((data) => setBook(data))
      .catch((err) => console.error(err));
  }, [bookId]);

  if (!book) return <p>Loading...</p>;

  return (
    <div>
      <h2>{book.title}</h2>
      <img src={book.coverImage} alt={book.title} />
      <p>{book.description}</p>
      <p>Author: {book.author}</p>
      <p>Price: ${book.price}</p>
      <p>Rent Price: ${book.rentPrice}</p>
      <p>Rent Duration: {book.rentDuration} days</p>
      <p>Seller: {book.user.username}</p>
      {/* Buttons to Buy or Rent */}
    </div>
  );
};

export default BookDetails;
