// src/components/UserProfile.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const UserProfile = () => {
  const [user, setUser] = useState(null);
  const [rating, setRating] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch user profile data
    const fetchUserProfile = async () => {
      try {
        const response = await axios.get("/api/users/profile", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setUser(response.data);
        setRating(response.data.rating); // Assuming rating is part of the user data
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };

    fetchUserProfile();
  }, []);

  const handleEditProfile = () => {
    navigate("/edit-profile");
  };

  return (
    <div className="user-profile">
      {user ? (
        <div>
          <h2>User Profile</h2>
          <div>
            <strong>Username:</strong> {user.username}
          </div>
          <div>
            <strong>Email:</strong> {user.email}
          </div>
          <div>
            <strong>Phone Number:</strong> {user.phoneNumber}
          </div>
          <div>
            <strong>Address:</strong> {user.address}
          </div>
          <div>
            <strong>Rating:</strong> {rating} ★
          </div>

          <button onClick={handleEditProfile}>Edit Profile</button>

          <h3>Transaction History</h3>
          {/* Render transaction history here */}
          <ul>
            {user.transactions &&
              user.transactions.map((transaction, index) => (
                <li key={index}>
                  {transaction.bookTitle} - {transaction.status}
                </li>
              ))}
          </ul>
        </div>
      ) : (
        <div>Loading...</div>
      )}
    </div>
  );
};

export default UserProfile;
