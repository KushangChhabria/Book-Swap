// src/components/Home.jsx

import React, { useState, useEffect } from "react";
import "./Home.css";

const Home = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    // Fetch books from the backend (Replace with actual API endpoint)
    fetch("http://localhost:5000/api/books")
      .then((res) => res.json())
      .then((data) => setBooks(data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="home">
      <h1>Welcome to Bookverse</h1>
      <h2>Recommended Books</h2>
      <div className="book-list">
        {books.map((book) => (
          <div key={book._id} className="book-card">
            <img src={book.coverImage} alt={book.title} />
            <h3>{book.title}</h3>
            <p>{book.author}</p>
            <p>Price: ${book.price}</p>
            <button>View Details</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
