// src/pages/ErrorPage.jsx

import React from "react";

const ErrorPage = () => {
  return (
    <div>
      <h1>404 - Page Not Found</h1>
    </div>
  );
};

export default ErrorPage;
