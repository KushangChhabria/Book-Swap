const mongoose = require("mongoose");

const BookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  author: { type: String, required: true },
  genre: { type: String, required: true },
  description: { type: String },
  coverImage: { type: String },
  price: { type: Number, required: true },
  rentPrice: { type: Number, required: true },
  rentDuration: { type: Number, required: true }, // Duration in days
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
});

module.exports = mongoose.model("Book", BookSchema);
