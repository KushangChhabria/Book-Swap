const jwt = require("jsonwebtoken");

// Function to generate a JWT token
const generateToken = (userId) => {
  return jwt.sign(
    { userId }, // Payload containing the user ID
    process.env.JWT_SECRET, // Secret key from the environment variable
    { expiresIn: "1h" } // Expiration time for the token (1 hour)
  );
};

module.exports = generateToken;
