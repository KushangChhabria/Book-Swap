const Book = require("../models/Book");

// Add a book
const addBook = async (req, res) => {
  const {
    title,
    author,
    genre,
    description,
    coverImage,
    price,
    rentPrice,
    rentDuration,
  } = req.body;

  try {
    const book = new Book({
      title,
      author,
      genre,
      description,
      coverImage,
      price,
      rentPrice,
      rentDuration,
      owner: req.user.id,
    });
    await book.save();
    res.status(201).json(book);
  } catch (err) {
    res.status(500).send("Server Error");
  }
};

// Get all books
const getBooks = async (req, res) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (err) {
    res.status(500).send("Server Error");
  }
};

// Get a book by ID
const getBookById = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ msg: "Book not found" });
    res.json(book);
  } catch (err) {
    res.status(500).send("Server Error");
  }
};

module.exports = { addBook, getBooks, getBookById };
