const Book = require("../models/Book");
const User = require("../models/User");

// Buy a book
const buyBook = async (req, res) => {
  const { bookId, buyerId } = req.body;

  try {
    // Find the book and the buyer
    const book = await Book.findById(bookId);
    const buyer = await User.findById(buyerId);

    if (!book || !buyer) {
      return res.status(404).json({ msg: "Book or Buyer not found" });
    }

    // Check if the buyer is the owner of the book
    if (book.owner.toString() === buyerId) {
      return res.status(400).json({ msg: "Cannot buy your own book" });
    }

    // Simulate buying logic (you can integrate payment logic here)
    // Add the book to the buyer's transaction history
    buyer.transactionHistory.push({
      type: "buy",
      book: bookId,
      price: book.price,
    });
    await buyer.save();

    // Remove the book from the marketplace (or mark it as sold)
    await Book.findByIdAndDelete(bookId);

    res.status(200).json({ msg: "Book purchased successfully", book });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server Error" });
  }
};

// Rent a book
const rentBook = async (req, res) => {
  const { bookId, renterId, rentDuration } = req.body;

  try {
    // Find the book and the renter
    const book = await Book.findById(bookId);
    const renter = await User.findById(renterId);

    if (!book || !renter) {
      return res.status(404).json({ msg: "Book or Renter not found" });
    }

    // Check if the renter is the owner of the book
    if (book.owner.toString() === renterId) {
      return res.status(400).json({ msg: "Cannot rent your own book" });
    }

    // Add the book rental to the renter's transaction history
    renter.transactionHistory.push({
      type: "rent",
      book: bookId,
      price: book.rentPrice,
      rentDuration,
    });
    await renter.save();

    // Update the book's rent duration or status (could add more logic for rented status)
    book.rentDuration = rentDuration;
    await book.save();

    res.status(200).json({ msg: "Book rented successfully", book });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server Error" });
  }
};

// Rate a user
const rateUser = async (req, res) => {
  const { ratedUserId, raterUserId, rating } = req.body;

  try {
    // Find the user to be rated
    const ratedUser = await User.findById(ratedUserId);
    const raterUser = await User.findById(raterUserId);

    if (!ratedUser || !raterUser) {
      return res.status(404).json({ msg: "User not found" });
    }

    if (rating < 0 || rating > 5) {
      return res.status(400).json({ msg: "Rating should be between 0 and 5" });
    }

    // Calculate the new rating (average of previous ratings)
    const totalRatings = ratedUser.rating * ratedUser.transactionHistory.length;
    const newTotalRatings = totalRatings + rating;
    const newTransactionCount = ratedUser.transactionHistory.length + 1;
    ratedUser.rating = newTotalRatings / newTransactionCount;

    // Add the rating to the rater's transaction history
    ratedUser.transactionHistory.push({
      type: "rating",
      rater: raterUserId,
      rating,
    });
    await ratedUser.save();

    res
      .status(200)
      .json({ msg: "User rated successfully", rating: ratedUser.rating });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server Error" });
  }
};

module.exports = { buyBook, rentBook, rateUser };
