// server/controllers/userController.js
const User = require("../models/User");
const bcrypt = require("bcryptjs"); // Ensure bcrypt is imported for hashing/comparing passwords
const generateToken = require("../utils/generateToken");

// User registration
const signupUser = async (req, res) => {
  const { firstName, lastName, email, password, username } = req.body;

  // Check if username already exists
  const userExists = await User.findOne({ username });
  if (userExists) {
    return res.status(400).json({ msg: "Username already taken" });
  }

  // Hash the password before saving the user
  const hashedPassword = await bcrypt.hash(password, 10);

  // Create new user
  const user = new User({
    firstName,
    lastName,
    email,
    password: hashedPassword,
    username,
  });

  await user.save();

  // Generate JWT token
  const token = generateToken(user._id);

  res.status(201).json({
    msg: "User created successfully",
    token, // Send the token back
  });
};

// User login
const loginUser = async (req, res) => {
  const { username, password } = req.body;

  // Find the user by username
  const user = await User.findOne({ username });
  if (!user) {
    return res.status(400).json({ msg: "User not found" });
  }

  // Compare the entered password with the stored hashed password
  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(400).json({ msg: "Invalid credentials" });
  }

  // Generate JWT token
  const token = generateToken(user._id);

  res.status(200).json({
    msg: "User logged in successfully",
    token, // Send the token back
  });
};

module.exports = { signupUser, loginUser };
