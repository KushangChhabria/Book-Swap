// server/routes/userRoutes.js
const express = require("express");
const router = express.Router();
const { signupUser, loginUser } = require("../controllers/userController");

// User registration route
router.post("/register", signupUser);

// User login route
router.post("/login", loginUser);

module.exports = router;
