const express = require("express");
const router = express.Router();
const {
  addBook,
  getBooks,
  getBookById,
} = require("../controllers/bookController");

// Book Routes
router.post("/add", addBook);
router.get("/", getBooks); // List all books
router.get("/:id", getBookById); // Get a specific book by ID

module.exports = router;
