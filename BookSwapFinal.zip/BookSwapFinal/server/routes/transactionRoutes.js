const express = require("express");
const router = express.Router();
const {
  buyBook,
  rentBook,
  rateUser,
} = require("../controllers/transactionController");

// Transaction Routes
router.post("/buy", buyBook);
router.post("/rent", rentBook);
router.post("/rate", rateUser);

module.exports = router;
